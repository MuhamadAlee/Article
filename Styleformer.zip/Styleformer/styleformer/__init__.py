from styleformer.styleformer import Styleformer
from styleformer.adequacy import Adequacy
